#!/usr/bin/bash
python -m unittest discover -v tests
