#!/usr/bin/bash
git clean -xdf
7za a AnkiConnect.zip ./plugin/*
