<script>
  import { onMount } from 'svelte'
  let quote
  onMount(async () => {
    try {
      const response = await fetch(`https://api.quotable.io/random`)
      console.log(11, response)
    } catch (e) {
      // nothing
    }
  })
</script>

<div>
  {#if quote}
    <h1>test</h1>
  {:else}
    <p>Loading...</p>
  {/if}
</div>
