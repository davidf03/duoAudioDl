# svelte-typescript-ext-template

Just a bare config to use for extensions

# How to run

run `yarn` to install all dependencies
to run in development mode `yarn start`
to build for production `yarn build`
Either will generate a usable extension into the `dist` folder
